package vn.vnrestonelinker.registry;

import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import vn.vnrestonelinker.VNRestoneLinkerMod;
import vn.vnrestonelinker.menu.GeneratorMenu;

public class MenuRegistry {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, VNRestoneLinkerMod.MODID);

    public static final RegistryObject<MenuType<GeneratorMenu>> GENERATOR_MENU =
            MENUS.register("generator_menu", () -> new MenuType<>(GeneratorMenu::new));
}
