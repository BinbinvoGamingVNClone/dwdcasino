package vn.vnrestonelinker.registry;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import vn.vnrestonelinker.VNRestoneLinkerMod;

public class ItemRegistry {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, VNRestoneLinkerMod.MODID);

    public static final RegistryObject<Item> GENERATOR_BLOCK = ITEMS.register("generator_block",
    () -> new BlockItem(BlockRegistry.GENERATOR_BLOCK.get(), new Item.Properties()));

public static final RegistryObject<Item> CONNECTOR_BLOCK = ITEMS.register("connector_block",
    () -> new BlockItem(BlockRegistry.CONNECTOR_BLOCK.get(), new Item.Properties()));
}
