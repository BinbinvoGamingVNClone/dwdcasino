package vn.ngaigimakolamvn.vnrestonelinker.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.network.NetworkHooks;
import vn.ngaigimakolamvn.vnrestonelinker.gui.GeneratorMenu;
import net.minecraft.world.MenuProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleMenuProvider;
import org.jetbrains.annotations.Nullable;

public class GeneratorBlock extends Block {
    public GeneratorBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                  Player player, InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide) {
            MenuProvider menu = new SimpleMenuProvider(
                (id, inv, p) -> new GeneratorMenu(id, inv),
                Component.literal("VNRestoneLinker")
            );
            NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) player, menu);
        }
        return InteractionResult.SUCCESS;
    }
}
