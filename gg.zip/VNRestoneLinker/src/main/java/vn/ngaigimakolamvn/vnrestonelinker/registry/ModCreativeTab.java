package vn.vnrestonelinker.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.CreativeModeTabEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import vn.vnrestonelinker.VNRestoneLinker;

@Mod.EventBusSubscriber(modid = VNRestoneLinker.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModCreativeTab {
    public static CreativeModeTab VNRESTONE_TAB;

    @SubscribeEvent
public static void registerCreativeTab(CreativeModeTabEvent.Register event) {
    VNRESTONE_TAB = event.registerCreativeModeTab(
        new ResourceLocation(VNRestoneLinker.MODID, "vnrestone_tab"),
        builder -> builder
            .icon(() -> new ItemStack(Items.REDSTONE)) // ← icon là redstone
            .title(Component.literal("VN Restone Linker"))
            .displayItems((params, output) -> {
                output.accept(BlockRegistry.GENERATOR_BLOCK.get());
                output.accept(BlockRegistry.CONNECTOR_BLOCK.get());
            })
    );
}

}
