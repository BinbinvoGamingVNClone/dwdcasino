package vn.ngaigimakolamvn.vnrestonelinker;

import vn.ngaigimakolamvn.vnrestonelinker.registry.BlockRegistry;
import vn.ngaigimakolamvn.vnrestonelinker.registry.ItemRegistry;
import vn.ngaigimakolamvn.vnrestonelinker.registry.MenuRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod("vnrestonelinker")
public class VNRestoneLinker {
    public static final String MODID = "vnrestonelinker";

    public VNRestoneLinker() {
        var modBus = FMLJavaModLoadingContext.get().getModEventBus();
        BlockRegistry.register(modBus);
        ItemRegistry.register(modBus);
        MenuRegistry.register(modBus);
    }
}
