package vn.vnrestonelinker.registry;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import vn.vnrestonelinker.VNRestoneLinkerMod;
import vn.vnrestonelinker.block.ConnectorBlock;
import vn.vnrestonelinker.block.GeneratorBlock;

public class BlockRegistry {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, VNRestoneLinkerMod.MODID);

    public static final RegistryObject<Block> GENERATOR_BLOCK = BLOCKS.register("generator_block",
            () -> new GeneratorBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(2.0f)));

    public static final RegistryObject<Block> CONNECTOR_BLOCK = BLOCKS.register("connector_block",
            () -> new ConnectorBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED).strength(2.0f)));
}
